Para complicar o projeto é necessário correr os seguintes comandos na consola: javac TintolmarketServer.java
										javac Tintolmarket.java


Para correr o projeto é necessário correr primeiro o servidor com os argumentos necessários: java -jar JarServer.jar
De seguida correm-se os clientes com os argumentos necessários : java -jar JarClient.jar

Limitações: não é possível enviar imagens
	    